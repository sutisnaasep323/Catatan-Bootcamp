package com.asep.myapplication.api

import com.asep.myapplication.response.QuranResponse
import retrofit2.Call
import retrofit2.http.*

interface ApiService {
    @GET("quran/{id}")
    fun getSurah(
        @Path("id") id: Int
    ): Call<QuranResponse>
}