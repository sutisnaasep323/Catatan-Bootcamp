package com.asep.myapplication.viewmodel

import androidx.lifecycle.ViewModel

class HomeViewModel: ViewModel() {
    var lastName: String? = null

    fun helloName(name: String){
       lastName = name
    }
}