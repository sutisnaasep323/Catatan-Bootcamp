package com.asep.myapplication.ui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import com.asep.myapplication.api.ApiConfig
import com.asep.myapplication.databinding.ActivityQuranBinding
import com.asep.myapplication.response.Data
import com.asep.myapplication.response.QuranResponse
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class QuranActivity : AppCompatActivity() {

    private lateinit var binding: ActivityQuranBinding

    companion object {
        private const val TAG = "QuranActivity"
        private const val QURAN_ID = 114
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityQuranBinding.inflate(layoutInflater)
        setContentView(binding.root)

        findSurah()
    }

    private fun findSurah() {
        showLoading(true)
        val client = ApiConfig.getApiService().getSurah(QURAN_ID)
        client.enqueue(object: Callback<QuranResponse>{
            override fun onResponse(call: Call<QuranResponse>, response: Response<QuranResponse>) {
                if (response.isSuccessful) {
                    showLoading(false)
                    val responseBody = response.body()
                    if (responseBody != null) {
                        setSurahData(responseBody.data)
                    }
                } else {
                    Log.e(TAG, "onFailure: ${response.message()}")
                }
            }

            override fun onFailure(call: Call<QuranResponse>, t: Throwable) {
                showLoading(true)
                Log.e(TAG, "onFailure: ${t.message}")
            }

        })
    }

    private fun setSurahData(surah: Data?) {
        binding.tvTitle.text = surah?.asma?.id?.jsonMemberLong
        binding.tvTranslate.text = surah?.asma?.translation?.id
    }

    private fun showLoading(isLoading: Boolean) {
        if (isLoading) {
            binding.progressBar.visibility = View.VISIBLE
        } else {
            binding.progressBar.visibility = View.GONE
        }
    }

}