package com.mobile.latihan.mytablayout

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageButton

class AboutProfileActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_about_profile)

        val back: ImageButton = findViewById(R.id.img_back)
        back.setOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }
    }
}