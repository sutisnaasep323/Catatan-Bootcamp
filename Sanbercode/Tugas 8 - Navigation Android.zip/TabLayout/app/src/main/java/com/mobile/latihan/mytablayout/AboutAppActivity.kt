package com.mobile.latihan.mytablayout

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageButton

class AboutAppActivity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_about_app)
        val back: ImageButton = findViewById(R.id.img_back)
        back.setOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }
    }
}