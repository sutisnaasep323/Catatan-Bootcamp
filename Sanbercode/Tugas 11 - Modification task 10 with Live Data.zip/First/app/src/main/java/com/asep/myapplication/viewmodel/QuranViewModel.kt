package com.asep.myapplication.viewmodel

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.asep.myapplication.api.ApiConfig
import com.asep.myapplication.response.Data
import com.asep.myapplication.response.QuranResponse
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class QuranViewModel: ViewModel() {

    private val _data = MutableLiveData<Data>()
    val data: LiveData<Data> = _data

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    companion object {
        private const val TAG = "QuranActivity"
        private const val QURAN_ID = 114
    }

    init {
        findSurah()
    }

    private fun findSurah() {
        _isLoading.value = true
        val client = ApiConfig.getApiService().getSurah(QURAN_ID)
        client.enqueue(object: Callback<QuranResponse> {
            override fun onResponse(call: Call<QuranResponse>, response: Response<QuranResponse>) {
                if (response.isSuccessful) {
                    _isLoading.value = false
                    if (response.isSuccessful) {
                        _data.value = response.body()?.data
                    }
                } else {
                    Log.e(TAG, "onFailure: ${response.message()}")
                }
            }

            override fun onFailure(call: Call<QuranResponse>, t: Throwable) {
                _isLoading.value = true
                Log.e(TAG, "onFailure: ${t.message}")
            }

        })
    }
}