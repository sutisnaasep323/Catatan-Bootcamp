package com.asep.myapplication.ui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.lifecycle.ViewModelProvider
import com.asep.myapplication.api.ApiConfig
import com.asep.myapplication.databinding.ActivityQuranBinding
import com.asep.myapplication.response.Data
import com.asep.myapplication.response.QuranResponse
import com.asep.myapplication.viewmodel.QuranViewModel
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class QuranActivity : AppCompatActivity() {

    private lateinit var binding: ActivityQuranBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityQuranBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val quranViewModel = ViewModelProvider(
            this,
            ViewModelProvider.NewInstanceFactory()
        ).get(QuranViewModel::class.java)


        quranViewModel.data.observe(this) { data ->
            setSurahData(data)
        }

        quranViewModel.isLoading.observe(this) {
            showLoading(it)
        }
    }

    private fun setSurahData(data: Data?) {
        binding.tvTitle.text = data?.asma?.id?.jsonMemberLong
        binding.tvTranslate.text = data?.asma?.translation?.id
    }

    private fun showLoading(isLoading: Boolean) {
        if (isLoading) {
            binding.progressBar.visibility = View.VISIBLE
        } else {
            binding.progressBar.visibility = View.GONE
        }
    }

}