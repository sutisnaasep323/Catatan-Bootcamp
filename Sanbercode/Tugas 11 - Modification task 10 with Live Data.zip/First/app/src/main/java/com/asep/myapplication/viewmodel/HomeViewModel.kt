package com.asep.myapplication.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class HomeViewModel: ViewModel() {

    var lastName: String? = null

    fun helloName(name: String){
       lastName = name
    }
}