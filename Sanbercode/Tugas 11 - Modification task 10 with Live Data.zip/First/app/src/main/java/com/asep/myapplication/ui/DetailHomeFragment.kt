package com.asep.myapplication.ui

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProvider
import com.asep.myapplication.databinding.FragmentDetailHomeBinding
import com.asep.myapplication.viewmodel.HomeViewModel

class DetailHomeFragment : Fragment() {

    private var _binding: FragmentDetailHomeBinding? = null
    private val binding get() = _binding!!
    var lastName: String? = null
    private lateinit var viewModel: HomeViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentDetailHomeBinding.inflate(inflater, container, false)
        val view = binding.root
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewModel = ViewModelProvider(requireActivity()).get(HomeViewModel::class.java)
        displayResult()

        if (arguments != null) {
            val name = arguments?.getString(EXTRA_NAME)
            binding.tvName.text = name
        }

        lastName?.let {
            viewModel.helloName(it)
        }

        displayResult()

    }

    private fun displayResult() {
        binding.tvLastName.text = viewModel.lastName
    }

    companion object {
        var EXTRA_NAME = "extra_name"
    }
}