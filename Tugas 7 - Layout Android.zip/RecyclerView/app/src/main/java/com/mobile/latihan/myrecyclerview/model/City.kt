package com.mobile.latihan.myrecyclerview.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class City(
    var name: String,
    var description: String,
    var photo: String
) : Parcelable
