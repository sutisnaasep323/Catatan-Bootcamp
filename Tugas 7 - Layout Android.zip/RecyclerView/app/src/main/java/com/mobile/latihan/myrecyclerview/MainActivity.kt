package com.mobile.latihan.myrecyclerview

import android.content.res.Configuration
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mobile.latihan.myrecyclerview.adapter.ListCityAdapter
import com.mobile.latihan.myrecyclerview.model.City
import java.util.*

class MainActivity : AppCompatActivity() {
    private lateinit var rvHeroes: RecyclerView
    private val list = ArrayList<City>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        rvHeroes = findViewById(R.id.rv_heroes)
        rvHeroes.setHasFixedSize(true)

        list.addAll(listCities)
        showRecyclerList()
    }

    private val listCities: ArrayList<City>
        get() {
            val dataName = resources.getStringArray(R.array.data_name)
            val dataDescription = resources.getStringArray(R.array.data_description)
            val dataPhoto = resources.getStringArray(R.array.data_photo)
            val listCity = ArrayList<City>()
            for (i in dataName.indices) {
                val city = City(dataName[i],dataDescription[i], dataPhoto[i])
                listCity.add(city)
            }
            return listCity
        }

    private fun showRecyclerList() {
        if (applicationContext.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            rvHeroes.layoutManager = GridLayoutManager(this, 2)
        } else {
            rvHeroes.layoutManager = LinearLayoutManager(this)
        }
        val listCityAdapter = ListCityAdapter(list)
        rvHeroes.adapter = listCityAdapter
        listCityAdapter.setOnItemClickCallback(object : ListCityAdapter.OnItemClickCallback {
            override fun onItemClicked(data: City) {
                showSelectedCity(data)
            }
        })
    }

    private fun showSelectedCity(city: City) {
        Toast.makeText(this, "Kamu memilih " + city.name, Toast.LENGTH_SHORT).show()
    }
}